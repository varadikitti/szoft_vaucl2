﻿namespace ZH2_VAUCL2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            buttonErdekessegek = new Button();
            dataGridView1 = new DataGridView();
            italIDDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            nevDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            alkoholtartalomDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            egysegArDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            nepszeruDataGridViewCheckBoxColumn = new DataGridViewCheckBoxColumn();
            classItalBindingSource2 = new BindingSource(components);
            classItalBindingSource = new BindingSource(components);
            buttonMentes = new Button();
            buttonBetoltes = new Button();
            buttonUjSor = new Button();
            buttonTorles = new Button();
            classItalBindingSource1 = new BindingSource(components);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)classItalBindingSource2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)classItalBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)classItalBindingSource1).BeginInit();
            SuspendLayout();
            // 
            // buttonErdekessegek
            // 
            buttonErdekessegek.Location = new Point(12, 12);
            buttonErdekessegek.Name = "buttonErdekessegek";
            buttonErdekessegek.Size = new Size(122, 23);
            buttonErdekessegek.TabIndex = 0;
            buttonErdekessegek.Text = "Érdekességek";
            buttonErdekessegek.UseVisualStyleBackColor = true;
            buttonErdekessegek.Click += buttonErdekessegek_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { italIDDataGridViewTextBoxColumn, nevDataGridViewTextBoxColumn, alkoholtartalomDataGridViewTextBoxColumn, egysegArDataGridViewTextBoxColumn, nepszeruDataGridViewCheckBoxColumn });
            dataGridView1.DataSource = classItalBindingSource2;
            dataGridView1.Location = new Point(12, 41);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(733, 368);
            dataGridView1.TabIndex = 1;
            // 
            // italIDDataGridViewTextBoxColumn
            // 
            italIDDataGridViewTextBoxColumn.DataPropertyName = "ItalID";
            italIDDataGridViewTextBoxColumn.HeaderText = "ItalID";
            italIDDataGridViewTextBoxColumn.Name = "italIDDataGridViewTextBoxColumn";
            // 
            // nevDataGridViewTextBoxColumn
            // 
            nevDataGridViewTextBoxColumn.DataPropertyName = "Nev";
            nevDataGridViewTextBoxColumn.HeaderText = "Nev";
            nevDataGridViewTextBoxColumn.Name = "nevDataGridViewTextBoxColumn";
            // 
            // alkoholtartalomDataGridViewTextBoxColumn
            // 
            alkoholtartalomDataGridViewTextBoxColumn.DataPropertyName = "Alkoholtartalom";
            alkoholtartalomDataGridViewTextBoxColumn.HeaderText = "Alkoholtartalom";
            alkoholtartalomDataGridViewTextBoxColumn.Name = "alkoholtartalomDataGridViewTextBoxColumn";
            // 
            // egysegArDataGridViewTextBoxColumn
            // 
            egysegArDataGridViewTextBoxColumn.DataPropertyName = "EgysegAr";
            egysegArDataGridViewTextBoxColumn.HeaderText = "EgysegAr";
            egysegArDataGridViewTextBoxColumn.Name = "egysegArDataGridViewTextBoxColumn";
            // 
            // nepszeruDataGridViewCheckBoxColumn
            // 
            nepszeruDataGridViewCheckBoxColumn.DataPropertyName = "Nepszeru";
            nepszeruDataGridViewCheckBoxColumn.HeaderText = "Nepszeru";
            nepszeruDataGridViewCheckBoxColumn.Name = "nepszeruDataGridViewCheckBoxColumn";
            // 
            // classItalBindingSource2
            // 
            classItalBindingSource2.DataSource = typeof(ClassItal);
            // 
            // classItalBindingSource
            // 
            classItalBindingSource.DataSource = typeof(ClassItal);
            // 
            // buttonMentes
            // 
            buttonMentes.Location = new Point(343, 12);
            buttonMentes.Name = "buttonMentes";
            buttonMentes.Size = new Size(75, 23);
            buttonMentes.TabIndex = 0;
            buttonMentes.Text = "Mentés";
            buttonMentes.UseVisualStyleBackColor = true;
            buttonMentes.Click += buttonMentes_Click;
            // 
            // buttonBetoltes
            // 
            buttonBetoltes.Location = new Point(424, 12);
            buttonBetoltes.Name = "buttonBetoltes";
            buttonBetoltes.Size = new Size(75, 23);
            buttonBetoltes.TabIndex = 0;
            buttonBetoltes.Text = "Betöltés";
            buttonBetoltes.UseVisualStyleBackColor = true;
            buttonBetoltes.Click += buttonBetoltes_Click;
            // 
            // buttonUjSor
            // 
            buttonUjSor.Location = new Point(424, 415);
            buttonUjSor.Name = "buttonUjSor";
            buttonUjSor.Size = new Size(75, 23);
            buttonUjSor.TabIndex = 0;
            buttonUjSor.Text = "Új sor";
            buttonUjSor.UseVisualStyleBackColor = true;
            buttonUjSor.Click += buttonUjSor_Click;
            // 
            // buttonTorles
            // 
            buttonTorles.Location = new Point(343, 415);
            buttonTorles.Name = "buttonTorles";
            buttonTorles.Size = new Size(75, 23);
            buttonTorles.TabIndex = 0;
            buttonTorles.Text = "Törlés";
            buttonTorles.UseVisualStyleBackColor = true;
            buttonTorles.Click += buttonTorles_Click;
            // 
            // classItalBindingSource1
            // 
            classItalBindingSource1.DataSource = typeof(ClassItal);
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(757, 450);
            Controls.Add(dataGridView1);
            Controls.Add(buttonTorles);
            Controls.Add(buttonUjSor);
            Controls.Add(buttonBetoltes);
            Controls.Add(buttonMentes);
            Controls.Add(buttonErdekessegek);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)classItalBindingSource2).EndInit();
            ((System.ComponentModel.ISupportInitialize)classItalBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)classItalBindingSource1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button buttonErdekessegek;
        private DataGridView dataGridView1;
        private Button buttonMentes;
        private Button buttonBetoltes;
        private Button buttonUjSor;
        private Button buttonTorles;
        private DataGridViewTextBoxColumn azonositoDataGridViewTextBoxColumn;
        private BindingSource classItalBindingSource;
        private BindingSource classItalBindingSource1;
        private DataGridViewTextBoxColumn italIDDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn nevDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn alkoholtartalomDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn egysegArDataGridViewTextBoxColumn;
        private DataGridViewCheckBoxColumn nepszeruDataGridViewCheckBoxColumn;
        private BindingSource classItalBindingSource2;
    }
}