﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZH2_VAUCL2
{
    public partial class FormUjSor : Form
    {
        public ClassItal UjItal = new ClassItal();
        public FormUjSor()
        {
            InitializeComponent();

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
            //ItalID,Nev,Alkoholtartalom,EgysegAr,Nepszeru
            UjItal.ItalID = int.Parse(textBox1.Text);
            UjItal.Nev = textBox2.Text;
            UjItal.Alkoholtartalom = int.Parse(textBox3.Text);
            UjItal.EgysegAr = int.Parse(textBox4.Text);
            //UjItal.Nepszeru = checkBox1.Text;

        }
    }
}
