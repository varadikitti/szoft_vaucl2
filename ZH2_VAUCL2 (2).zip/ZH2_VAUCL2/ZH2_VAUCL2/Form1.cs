using CsvHelper;
using System.ComponentModel;
using System.Globalization;

namespace ZH2_VAUCL2
{
    public partial class Form1 : Form
    {
        BindingList<ClassItal> italList = new BindingList<ClassItal>();
        public Form1()
        {
            InitializeComponent();
            //dataGridView1.AutoGenerateColumns = true;
            //dataGridView1.DataSource = italList;
            classItalBindingSource.DataSource = italList;
            dataGridView1.DataSource = classItalBindingSource;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonBetoltes_Click(object sender, EventArgs e)
        {
            try
            {
                StreamReader sr = new StreamReader("italok.txt");
                var csv = new CsvReader(sr, CultureInfo.InvariantCulture);
                var tomb = csv.GetRecords<ClassItal>();
                foreach (var item in tomb)
                {
                    italList.Add(item);
                }
                sr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void bindingSource1_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void buttonMentes_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    StreamWriter streamWriter = new StreamWriter(saveFileDialog.FileName);
                    var csv = new CsvWriter(streamWriter, CultureInfo.InvariantCulture);
                    csv.WriteRecords(italList);
                    streamWriter.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void buttonTorles_Click(object sender, EventArgs e)
        {
            if (classItalBindingSource.Current == null) return;
            if (MessageBox.Show("Biztosan t�r�lni akarja a sort?", "Sor t�rl�se", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                classItalBindingSource.RemoveCurrent();
            }

        }

        private void buttonUjSor_Click(object sender, EventArgs e)
        {
            FormUjSor formUjSor = new FormUjSor();
            if (formUjSor.ShowDialog() == DialogResult.Yes)
            {
                italList.Add(formUjSor.UjItal);
            }
        }

        private void buttonErdekessegek_Click(object sender, EventArgs e)
        {
            int nepszeru = 0;
            double legnagyobb = 0;
            string melyik = string.Empty;
            foreach (var item in italList)
            {
                if (item.Nepszeru == true)
                {
                    nepszeru++;
                }
                if (item.Alkoholtartalom >legnagyobb)
                {
                    legnagyobb = item.Alkoholtartalom;
                    melyik = item.Nev;
                }
            }
            MessageBox.Show($"A list�ban {nepszeru} n�pszer� ital szerepel. �rdemes a {melyik} italt v�lasztani, ennek alkoholtartalma pedig {legnagyobb}.");
        }
    }
}