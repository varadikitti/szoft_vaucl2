﻿using gyak2.Data;
using gyak2.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gyak2
{
    public partial class UgyfelForm : Form
    {
        
        private RendelesDbContext _context;


        public UgyfelForm()
        {
            InitializeComponent();
            _context = new RendelesDbContext();
            LoadData();
        }

        // ADATBETÖLTÉS // A LoadData() metódus betölti az összes ügyfelet az adatbázisból és megjeleníti őket a DataGridView-ban.
        private void LoadData()
        {
            ugyfelBindingSource.DataSource = _context.Ugyfel.ToList();
        }


        // ÚJ // CREATE // Az “Új” gomb létrehoz egy új Ugyfel objektumot alapértelmezett adatokkal, hozzáadja az adatbázishoz, majd frissíti a DataGridView-t.
        private void button1_Click(object sender, EventArgs e)
        {
            var ujUgyfel = new Ugyfel { Nev = "Új Ügyfél", Email = "uj@pelda.com" };
            _context.Ugyfel.Add(ujUgyfel);
            _context.SaveChanges();
            LoadData();
        }


        // TÖRLÉS // DELETE // A “Törlés” gomb eltávolítja a kijelölt ügyfelet az adatbázisból és frissíti a DataGridView-t.
        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                var torlendoUgyfel = dataGridView1.CurrentRow.DataBoundItem as Ugyfel;
                if (torlendoUgyfel != null)
                {
                    _context.Ugyfel.Remove(torlendoUgyfel);
                    _context.SaveChanges();
                    LoadData();
                }
            }
        }


        // MENTÉS // UPDATE // A “Mentés” gomb egyszerűen elmenti a DataGridView-ban végrehajtott módosításokat az adatbázisba.
        private void button3_Click(object sender, EventArgs e)
        {
            _context.SaveChanges();
            LoadData();
        }


        // FRISSÍTÉS // FRISSÍTÉS //
        private void button4_Click(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
