﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_vaucl2
{
    internal class kartya : PictureBox
    {
        public int kintKepSzam;

        public kartya(int sor, int oszlop, int kepSzam)
        {
            kintKepSzam = kepSzam;

            Height = Properties.Settings.Default.kepMeret;
            Width = Properties.Settings.Default.kepMeret;

            Left = oszlop * Properties.Settings.Default.kepTavolsag + 20;
            Top = sor * Properties.Settings.Default.kepTavolsag + 20;

            this.Click += Kartya_Click;

            Lefordit();
        }

        public void Kartya_Click(object sender, EventArgs e)
        {
            Felfordit();
        }

        public void Felfordit()
        {
            Image = Bitmap.FromFile(Properties.Settings.Default.kepKonyvtar + kintKepSzam.ToString() + Properties.Settings.Default.kepUtotag);
        }

        public void Lefordit()
        {
            Image = Bitmap.FromFile(Properties.Settings.Default.kepKonyvtar + "card_back" + Properties.Settings.Default.kepUtotag);
        }
    }
}
