﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_vaucl2
{
    public partial class Form1 : Form
    {
        kartya elozoKartya;

        List<kartya> szamlalo = new List<kartya>();

        public int size = 2;
        public int timeSpent;
        public int goodOnes;
        public int all;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            BackgroundImage = Bitmap.FromFile(Properties.Settings.Default.hatterkep);
            Width = BackgroundImage.Width;
            Height = BackgroundImage.Height;

            listBox1.Items.Add("Easy Peasy");
            listBox1.Items.Add("Medium for slow learners");
            listBox1.Items.Add("Hard for smarty-pants");
        }

        int[] Keveres(int kartyaSzam)
        {
            int[] tomb = new int[kartyaSzam];

            for (int i = 0; i < kartyaSzam / 2; i++)
            {
                tomb[i] = i + 1;
                tomb[i + kartyaSzam / 2] = i + 1;
            }

            Random rnd = new Random();

            for (int i = 1; i < kartyaSzam; i++)
            {
                int egyik = rnd.Next(kartyaSzam);
                int masik = rnd.Next(kartyaSzam);

                int seged = tomb[egyik];
                tomb[egyik] = tomb[masik];
                tomb[masik] = seged;
            }
            return tomb;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == 0) {size = 2;}
            else if (listBox1.SelectedIndex == 1) {size = 4;}
            else {size = 6;}

            panel1.Controls.Clear();
            int sorSzam = 0;
            int[] t = Keveres(size * size);

            for (int s = 0; s < size; s++)
            {
                for (int o = 0; o < size; o++)
                {
                    kartya k = new kartya(s, o, t[sorSzam]);
                    panel1.Controls.Add(k);

                    k.Click += K_Click;

                    sorSzam++;
                }
            }
        }

        private void K_Click(object sender, EventArgs e)
        {
            all++;

            if (all == 1)
            {
                timer1.Start();
            }

            if (sender is kartya)
            {
                kartya k = (kartya)sender;

                if (szamlalo.Count() <= 1)
                {
                    k.Felfordit();
                    szamlalo.Add(k);
                }
                else
                {
                    foreach (var v in szamlalo)
                    {
                        v.Lefordit();
                    }

                    szamlalo.Clear();

                    k.Felfordit();
                    szamlalo.Add(k);
                }

                if (all % 2 == 0 && elozoKartya != null)
                {
                    if (k.kintKepSzam == elozoKartya.kintKepSzam && k != elozoKartya)
                    {
                        k.Visible = false;
                        elozoKartya.Visible = false;

                        goodOnes++;
                    }
                }
                elozoKartya = k;
            }

            label2.Text = goodOnes.ToString();
            label3.Text = (all / 2 - goodOnes).ToString();

            if (goodOnes == (size * size) / 2)
            {
                timer1.Stop();

                if (size < 6)
                {
                    MessageBox.Show($"Congratulations! The # of good matches is {goodOnes}, and the # of your bad matches is {all / 2 - goodOnes}. Select a harder mode it was too easy for you! :)");
                }
                else
                {
                    MessageBox.Show($"Congratulations! The # of good matches is {goodOnes}, and the # of your bad matches is {all / 2 - goodOnes}. I can see you are a pro in this game, try to reduce your time though. XD");
                }                
                
                timeSpent = 0;
                all = 0;
                goodOnes = 0;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timeSpent++;
            label1.Text = "Time Spent: " + timeSpent.ToString() + " seconds";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Text = "Try harder! :)";
            button1.BackColor = Color.YellowGreen;
        }
    }
}
