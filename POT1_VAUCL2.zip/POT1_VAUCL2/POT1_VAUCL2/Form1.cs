namespace POT1_VAUCL2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // * * * * * * * * * * * *  F I B O N A C C I  * * * * * * * * * * * * //

        public class Sor
        {
            public long Sorszam { get; set; }
            public long Fibonacci { get; set; }
        }

        int FibonacciFV(int n)
        {
            if (n == 0) return 0;
            if (n == 1) return 1;
            return FibonacciFV(n - 1) + FibonacciFV(n - 2);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<Sor> Sorszam = new List<Sor>();

            for (int i = 0; i < 10; i++)
            {
                Sor sor = new Sor();

                sor.Sorszam = i + 1;
                sor.Fibonacci = FibonacciFV(i);

                Sorszam.Add(sor);
            }

            dataGridView1.DataSource = Sorszam;
        }


        // * * * * * * * * * * * *  L I K E   B U T T O N  * * * * * * * * * * * * //

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();

            try
            {
                int darab = int.Parse(textBox1.Text.ToString());

                for (int i = 0; i < darab; i++)
                {
                    LikeButton likeButton = new LikeButton();

                    likeButton.Top = i * likeButton.Height + 10;
                    //likeButton.Left = panel1.Width / 2 - likeButton.Width / 2;

                    panel1.Controls.Add(likeButton);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}