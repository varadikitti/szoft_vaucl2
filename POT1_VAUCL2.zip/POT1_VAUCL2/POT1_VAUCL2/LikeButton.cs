﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POT1_VAUCL2
{
    internal class LikeButton : Label
    {
        int szamolo;

        public LikeButton()
        {
            AutoSize = true;
            BackColor = Color.Gray;
            Text = "☆☆☆☆"; //☆☆☆☆ ★★★★

            Click += LikeButton_Click;
        }

        private void LikeButton_Click(object? sender, EventArgs e)
        {
            szamolo++;

            if (szamolo == 1) { Text = "★☆☆☆"; }
            else if (szamolo == 2) { Text = "★★☆☆"; }
            else if (szamolo == 3) { Text = "★★★☆"; }
            else if (szamolo == 4) { Text = "★★★★"; }
            else 
            { 
                Text = "☆☆☆☆";
                szamolo = 0;
            }
        }
    }
}
