﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZH3D_VAUCL2.Models;

namespace ZH3D_VAUCL2
{
    public partial class UserControl3 : UserControl
    {
        se_bikestoreContext context = new se_bikestoreContext();
        public UserControl3()
        {
            InitializeComponent();
        }

        private void UserControl3_Load(object sender, EventArgs e)
        {
            var er = from x in context.Categories
                     select new
                     {
                         categorySK = x.CategorySk,
                         categoryName = x.CategoryName
                     };


            dataGridView1.DataSource = er.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            if (form2.ShowDialog() == DialogResult.OK)
            {
                Category category = new Category();

                category.CategoryName = form2.textBox2.Text;

                context.Categories.Add(category);

                try
                {
                    context.SaveChanges();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }

            dataGridView1.DataSource = (from x in context.Categories select x).ToList();
        }
    }
}
