﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZH3D_VAUCL2.Models;

namespace ZH3D_VAUCL2
{
    public partial class UserControl4 : UserControl
    {
        se_bikestoreContext context = new se_bikestoreContext();
        public UserControl4()
        {
            InitializeComponent();
        }

        private void UserControl4_Load(object sender, EventArgs e)
        {
            var maxtermek = (from x in context.OrderItems
                             select x.ListPrice).Max();
            label1.Text = "legmagasabb termékár: " + maxtermek;

            var legd = (from x in context.OrderItems
                        where x.ListPrice == maxtermek
                        select x.ProductFkNavigation.ProductName);
            MessageBox.Show($"{string.Join(';', legd)}");
            var db = context.Products.Count();
            MessageBox.Show($"{legd}");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
