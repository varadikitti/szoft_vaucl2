﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZH3D_VAUCL2.Models;

namespace ZH3D_VAUCL2
{
    public partial class UserControl1 : UserControl
    {
        se_bikestoreContext context = new se_bikestoreContext();
        public UserControl1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var ment = from x in context.Products
                     select new
                     {
                         productSk = x.ProductSk,
                         productName = x.ProductName,
                         brandId = x.BrandId,
                         categoryFk = x.CategoryFkNavigation.CategoryName,
                         modelYear = x.ModelYear,
                         listPrice = x.ListPrice
                     };

            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    StreamWriter sw = new StreamWriter(saveFileDialog.FileName);
                    var csv = new CsvWriter(sw,CultureInfo.InvariantCulture);
                    csv.WriteRecords(ment);
                    sw.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void UserControl1_Load(object sender, EventArgs e)
        {
            var er = from x in context.Products
                     select new
                     {
                         productSk = x.ProductSk,
                         productName = x.ProductName,
                         brandId = x.BrandId,
                         categoryFk = x.CategoryFkNavigation.CategoryName,
                         modelYear = x.ModelYear,
                         listPrice = x.ListPrice
                     };


            dataGridView1.DataSource = er.ToList();

        }
    }
}
