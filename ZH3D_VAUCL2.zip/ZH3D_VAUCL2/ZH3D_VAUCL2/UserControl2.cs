﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZH3D_VAUCL2.Models;

namespace ZH3D_VAUCL2
{
    public partial class UserControl2 : UserControl
    {
        se_bikestoreContext context = new se_bikestoreContext();
        public UserControl2()
        {
            InitializeComponent();
            //FillDataSource();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItems == null) return;
            var marka = (Brand)listBox1.SelectedItem;
        }

        private void UserControl2_Load(object sender, EventArgs e)
        {
            var er = from x in context.Brands
                     select x;
            listBox1.DataSource = er.ToList();
            listBox1.DisplayMember = "brand_name";

            //var termek = from x in context.Products
             //            where x.Brand == marka.brand_id
               //          select x;


        }
    }
}
